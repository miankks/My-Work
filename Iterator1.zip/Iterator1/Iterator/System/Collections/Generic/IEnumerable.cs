﻿//namespace System.Collections.Generic
//{
//    internal interface IEnumerable
//    {
//    }
//}