﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    
    class LimitedList<T> : IEnumerable<T> where T : class
    {
        private T[] elements;

        public int Capacity { get;}
        public int Count { get;private set; }

        public LimitedList(int capacity)
        {
            Capacity = capacity;
            elements = new T[capacity];
        }

        public bool Add(T element)
        {
            if (Count >= Capacity) return false;
            for (int i = 0; i < Capacity; i++)
            {
                if (elements[i] == null)
                {

                    elements[i] = element;
                    Count++;
                    return true;
                }
            }
            return false;
        }
        public T Remove(T element)
        {
            for (int i = 0; i < Capacity; i++)
            {
                if (elements[i].Equals(element))
                {

                    elements[i] =default(T);
                    Count--;
                    return element;
                }
            }
            return default(T);
        }



        //public IEnumerator<T> GetEnumerator()
        //{
        //    for (int i = 0; i < Count; i++)
        //    {
        //        yield return elements[i];
        //    }
        //}
        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < Capacity; i++)
            {
                if(elements[i]!= null)
                {
                    yield return elements[i];
                }
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
