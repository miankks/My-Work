﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    class Program
    {
        static void Main(string[] args)
        {
            #region
            // Console.WriteLine(Naturals());

            //var naturals = Naturals();
            //foreach (var item in naturals)
            //{
            //    Console.WriteLine(item);
            //    //Console.Read();
            //}
            //Console.ReadKey();
            //var naturals = Naturals();
            //foreach (var item in Naturals())
            //{
            //    Console.WriteLine(item);
            //    //Console.Read();
            //}
            //Console.ReadKey();
            #endregion
            // Explicit Loop
            //var enumerator =  Naturals().GetEnumerator();
            //Console.WriteLine(enumerator.Current);
            //while (enumerator.MoveNext())
            //{
            //    Console.WriteLine(enumerator.Current);
            //    Console.ReadLine();
            //}


            //LimitedList(backpack)
            //var backPack = new LimitedList<int>(4);
            //backPack.Add(4);
            //backPack.Add(2);
            //backPack.Add(6);
            //backPack.Add(8);
            //backPack.Add(0);
            var backPack = new LimitedList<string>(10);
            bool added;
            int count = 0;
            do
            {
                count++;
               added = backPack.Add($"Item {count}");
            } while (added);

            Inventory(backPack);
            //do
            //{
            //    remove = backPack.Remove($"Item {count}");
            //    count--;
            //    Console.ReadLine();
            //} while (remove);
            count = 0;
            string remove = null;
            foreach (var item in backPack)
            {
                if (count == 3)
                {
                    remove = item;
                }
                count++;
               // Console.WriteLine(item);
            }
            backPack.Remove(remove);
            Inventory(backPack);
            Console.Read();

        }

        private static void Inventory(LimitedList<string> backPack)
        {
            Console.WriteLine($"{backPack.Count}");
            foreach (var item in backPack)
            {
                Console.WriteLine(item);
            }
        }

        //static IEnumerable<int> Naturals()
        //{
        //    //int i = Int32.MaxValue-10;
        //    int i = 7;
        //    while (true)
        //    {
        //        yield return i++;
        //    }
        //}


    }
}
