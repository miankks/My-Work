﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    /// <summary>
    /// For different type vehicles
    /// </summary>
    class Vehicle
    {
        public string RegNumber { get; set; }
        public string Color { get; set; }
        public int NumberOfWheels { get; set; }
        public string Name { get; set; }

        public virtual string Stats()
        {
           return $"\n\n{GetType().Name} \t  Name: {this.Name}\t\t RegNr:" +
                 $"{this.RegNumber}\t\t  Color: {this.Color}\t\tNr of Wheels:{this.NumberOfWheels}\t ";
        }
    }
}
