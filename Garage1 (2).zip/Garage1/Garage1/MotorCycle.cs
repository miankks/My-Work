﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class MotorCycle : Vehicle
    {
        public double CylinderVolume { get; set; }
        public override string Stats()
        {
           return base.Stats()+ $"\nCylinderVolume: {CylinderVolume}";
        }
    }
}
