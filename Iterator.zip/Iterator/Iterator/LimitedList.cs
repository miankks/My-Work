﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    class LimitedList<T> : IEnumerable<T>
    {
        private T[] elements;

        public int Capacity { get;}
        public int Count { get;private set; }

        public LimitedList(int capacity)
        {
            Capacity = capacity;
            elements = new T[capacity];
        }

        public bool Add(T element)
        {
            if (Count >= Capacity) return false;
            elements[Count] = element;
            Count++;
            return true;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < Count; i++)
            {
                yield return elements[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
